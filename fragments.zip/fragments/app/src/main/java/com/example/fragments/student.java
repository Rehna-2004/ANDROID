package com.example.fragments;

import androidx.fragment.app.Fragment;

public class student extends Fragment {

    public student() {
        super(R.layout.fragment_student);
    }
}