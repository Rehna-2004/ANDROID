package com.example.fragments;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.fragments.home;
import com.example.fragments.student;

public class MainActivity extends AppCompatActivity {

    Button btnHome, btnStudent, btnCollege;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnHome = findViewById(R.id.home);
        btnStudent = findViewById(R.id.student);
        btnCollege = findViewById(R.id.college);

        // Home displayed first
        loadFragment(new home());

        btnHome.setOnClickListener(v -> {
            loadFragment(new home());
        });

        btnStudent.setOnClickListener(v -> {
            loadFragment(new student());
        });

        btnCollege.setOnClickListener(v -> {
            loadFragment(new com.example.fragments.teacher());
        });
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit();
    }
}
