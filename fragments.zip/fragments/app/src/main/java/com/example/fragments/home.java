package com.example.fragments;

import androidx.fragment.app.Fragment;

public class home extends Fragment {

    public home() {
        super(R.layout.fragment_home);
    }
}