package com.example.fragments;

import androidx.fragment.app.Fragment;

public class teacher extends Fragment {

    public teacher() {
        super(R.layout.fragment_teacher);
    }
}